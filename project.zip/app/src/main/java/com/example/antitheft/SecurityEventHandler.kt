package com.example.antitheft

import android.content.Context
import android.telephony.SmsManager
import android.util.Log
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.tasks.await
import java.util.*

object SecurityEventHandler {
    private const val PREF = "antitheft_prefs"
    private const val KEY_ATTEMPTS = "attempts"
    private const val MAX_ATTEMPTS = 3
    private val TAG = "SecurityEventHandler"

    suspend fun handleFailedAttempt(context: Context) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val attempts = prefs.getInt(KEY_ATTEMPTS, 0) + 1
        prefs.edit().putInt(KEY_ATTEMPTS, attempts).apply()

        Log.d(TAG, "Failed attempts = $attempts")

        if (attempts >= MAX_ATTEMPTS) {
            prefs.edit().putInt(KEY_ATTEMPTS, 0).apply()
            try {
                val fused = LocationServices.getFusedLocationProviderClient(context)
                val loc = try { fused.lastLocation.await() } catch (e: Exception) { null }

                val lat = loc?.latitude ?: 0.0
                val lon = loc?.longitude ?: 0.0
                sendSmsWithLocation(context, lat, lon)
            } catch (e: Exception) {
                Log.e(TAG, "Location/SMS error: ${e.localizedMessage}")
                sendSmsWithLocation(context, 0.0, 0.0)
            }
        }
    }

    private fun sendSmsWithLocation(context: Context, lat: Double, lon: Double) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val phone = prefs.getString("alert_phone", null) ?: return
        val text = "جهازي مفقود! آخر موقع: https://maps.google.com/?q=$lat,$lon - ${Date()}"
        try {
            val sms = SmsManager.getDefault()
            sms.sendTextMessage(phone, null, text, null, null)
            Log.d(TAG, "SMS sent to $phone")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send SMS: ${e.localizedMessage}")
        }
    }
}
