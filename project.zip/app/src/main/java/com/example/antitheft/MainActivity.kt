package com.example.antitheft

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private lateinit var phoneInput: EditText
    private lateinit var activateBtn: Button
    private val REQUEST_CODE_ENABLE_ADMIN = 100
    private val PERMISSIONS = arrayOf(
        android.Manifest.permission.SEND_SMS,
        android.Manifest.permission.ACCESS_FINE_LOCATION
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        phoneInput = EditText(this)
        activateBtn = Button(this).apply { text = "تفعيل الحماية (عربي)" }
        val layout = androidx.constraintlayout.widget.ConstraintLayout(this)
        layout.id = 1
        phoneInput.id = 2
        activateBtn.id = 3
        layout.addView(phoneInput)
        layout.addView(activateBtn)
        setContentView(layout)

        ActivityCompat.requestPermissions(this, PERMISSIONS, 0)

        activateBtn.setOnClickListener {
            val phone = phoneInput.text.toString().trim()
            if (phone.isEmpty()) {
                Toast.makeText(this, "اكتب رقم التليفون المستلم", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val prefs = getSharedPreferences("antitheft_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("alert_phone", phone).apply()

            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val comp = ComponentName(this, MyDeviceAdminReceiver::class.java)
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "يُستخدم لاكتشاف محاولات فتح القفل وإرسال موقع الجهاز عند السرقة")
            startActivityForResult(intent, REQUEST_CODE_ENABLE_ADMIN)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_ENABLE_ADMIN) {
            if (resultCode == Activity.RESULT_OK) {
                Toast.makeText(this, "تم تفعيل مدير الجهاز بنجاح", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "لم تقم بتفعيل مدير الجهاز — التطبيق لن يعمل بالكامل", Toast.LENGTH_LONG).show()
            }
        }
    }
}
